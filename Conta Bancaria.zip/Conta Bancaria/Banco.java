import java.util.ArrayList;
import java.util.List;
	
public class Banco {
	
		private List<Conta> contas = new ArrayList<Conta>(5);
		private double total = 0;
		public List<Conta> getContas() {
			return contas;
		}

		public void insere(Conta c){
			this.total += c.getSaldo();
			this.contas.add(c);	
		}
		
		public double getTotal() {
			this.total = 0;
			for (Conta conta : this.contas) {
				System.out.println(conta.getSaldo());
				this.total+=conta.getSaldo();
			}
			return this.total;
		}

		public void setTotal(double total) {
			this.total = total;
		}

		public void mostra(){
			float soma= 0;
			for (Conta conta : this.contas) {
				System.out.println(conta.getSaldo());
				soma+=conta.getSaldo();
			}
			System.out.println("Soma dos saldos :"+soma);
			
		}
		
}
