
public class Principal {

	public static void main(String[] args) {
		Banco banco = new Banco();
		Conta conta1 = new Conta();
		Conta conta2 = new Conta();
		Conta conta3 = new Conta();
		
		banco.insere(conta1);
		banco.getContas().get(0).getTitular().setNome("Batman");
		banco.getContas().get(0).getTitular().setCPF("123");
		banco.getContas().get(0).getTitular().getNasc().setDia(30);
		banco.getContas().get(0).getTitular().getNasc().setMes(03);
		banco.getContas().get(0).getTitular().getNasc().setAno(1939);
		banco.getContas().get(0).deposita(1500);
		banco.getContas().get(0).saca(400);
		banco.getContas().get(0).transfere(conta2, 400);
		banco.getContas().get(0).mostra();
		
		banco.insere(conta2);
		banco.getContas().get(1).getTitular().setNome("Deadpool");
		banco.getContas().get(1).getTitular().setCPF("456");
		banco.getContas().get(1).getTitular().getNasc().setDia(18);
		banco.getContas().get(1).getTitular().getNasc().setMes(02);
		banco.getContas().get(1).getTitular().getNasc().setAno(1991);
		banco.getContas().get(1).deposita(2000);
		banco.getContas().get(1).saca(300);
		banco.getContas().get(1).transfere(conta3, 200);
		banco.getContas().get(1).mostra();
		
		banco.insere(conta3);
		banco.getContas().get(2).getTitular().setNome("Thanos");
		banco.getContas().get(2).getTitular().setCPF("789");
		banco.getContas().get(2).getTitular().getNasc().setDia(06);
		banco.getContas().get(2).getTitular().getNasc().setMes(02);
		banco.getContas().get(2).getTitular().getNasc().setAno(1973);
		banco.getContas().get(2).deposita(3000);
		banco.getContas().get(2).saca(600);
		banco.getContas().get(2).transfere(conta1, 500);
		banco.getContas().get(2).mostra();
		
		System.out.println("Total no banco :"+banco.getTotal());
	}
}
