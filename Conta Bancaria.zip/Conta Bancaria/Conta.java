public class Conta {
	
	Conta(){
		this.saldo = 0;
		this.numero = Conta.c++;
	}
	
	private static int c = 0;
	private int numero;
	private Cliente titular = new Cliente();
	private double limite = 2000;
	private double saldo = 0;
	
	public int getNumero(){
		return this.numero;
	}
	
	public void setNumero(int numero){
		this.numero = numero;
	}
	
	public void setTitular(Cliente titular){
		this.titular = titular;
	}
	
	public Cliente getTitular(){
		return this.titular;
	}
	
	public double getSaldo(){
		return this.saldo;
	}
	
	public double getLimite(){
		return this.limite;
	}
	
	public void deposita(double valor){
		this.saldo += valor;
	}
	
	public boolean saca(double valor){
		if(valor <= (this.saldo + this.limite)){
			this.saldo -= valor;
			return true;
		}else{
			return false;
		}
	}
	
	public boolean transfere(Conta destino, double valor){
		if(this.saca(valor)){
			destino.deposita(valor);
			return true;
		}else{
			return false;
		}
	}
	
	public void mostra(){
		System.out.println("Numero.: "+this.getNumero());
		this.titular.mostra();
		System.out.println("Limite.: "+this.getLimite());
		System.out.println("Saldo..: "+this.getSaldo());
		System.out.println();
	}
}
