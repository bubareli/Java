public class Cliente {
	private String nome;
	private String CPF;
	private Data nasc = new Data();
	
	public String getNome(){
		return this.nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public String getCPF(){
		return this.CPF;
	}
	
	public void setCPF(String CPF){
		this.CPF = CPF;
	}
	
	public Data getNasc(){
		return this.nasc;
	}
	
	public void setNasc(Data nasc){
		this.nasc = nasc;
	}
	
	public void mostra(){
		System.out.println("Nome...: "+this.getNome());
		System.out.println("CPF....: "+this.getCPF());
		System.out.print("Nasc...: ");
		this.nasc.mostra();
	}
}
